package com.example.artwork

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.artwork.ui.theme.ArtworkTheme
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow


class Main : ComponentActivity() {
    override fun onCreate(save: Bundle?) {
        super.onCreate(save)
        setContent {
            ArtworkTheme {
                design()
            }
        }
    }
}

@Composable
fun design() {
    var dep by remember { mutableStateOf(1) }

    Surface(
        modifier = Modifier
            .fillMaxSize(),
        color = Color(0xFFE0FFFF),
        shape = RoundedCornerShape(20.dp),
        contentColor = Color.Blue,
        tonalElevation = 50.dp,
        shadowElevation = 10.dp,
        border = BorderStroke(2.dp, Color.Gray)
    ) {
        when (dep) {
            1 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(30.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    backgroung(
                        picture = R.drawable.p1,
                        specification = R.string.definition
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    Definition(
                        head = R.string.name,
                        author = R.string.art1_name,
                        annum = R.string.year1
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    key(
                        Back = { dep = 5 },
                        ahead = { dep = 2 }
                    )
                }
            }

            2 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(30.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    backgroung(
                        picture = R.drawable.p2,
                        specification = R.string.definition
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    Definition(
                        head = R.string.name2,
                        author = R.string.art2_name,
                        annum = R.string.year2
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    key(
                        Back = { dep = 1 },
                        ahead = { dep = 3 })
                }
            }

            3 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(30.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    backgroung(
                        picture = R.drawable.p3,
                        specification = R.string.definition
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    Definition(
                        head = R.string.name3,
                        author = R.string.art3_name,
                        annum = R.string.year3
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    key(
                        Back = { dep = 2 },
                        ahead = { dep = 4 })
                }
            }

            4 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(30.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    backgroung(
                        picture = R.drawable.p4,
                        specification = R.string.definition
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    Definition(
                        head = R.string.name4,
                        author = R.string.art4_name,
                        annum =R.string.year4
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    key(
                        Back = { dep = 3 },
                        ahead = { dep = 5 })
                }
            }

            5 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(30.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    backgroung(
                        picture = R.drawable.p5,
                        specification = R.string.definition
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    Definition(
                        head = R.string.name5,
                        author = R.string.art5_name,
                        annum = R.string.year5
                    )
                    Spacer(modifier = Modifier.height(25.dp))
                    key(
                        Back = { dep = 4 },
                        ahead = { dep = 1 })
                }
            }
        }
    }
}


@Composable
fun backgroung(
    picture: Int,
    specification: Int
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(480.dp),
        color = Color.White,
        shadowElevation = 30.dp,
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 40.dp
    ) {
        Image(
            painter = painterResource(
                id = picture
            ),
            contentDescription = stringResource(specification),
            contentScale = ContentScale.FillBounds,
            alignment = Alignment.Center,
            alpha = 1f

        )
    }
}

@Composable
fun Definition(
    head: Int,
    author: Int,
    annum: Int
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp),
        shadowElevation = 25.dp,
        color = Color(0xFFF0FFFF),
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 40.dp
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
        ) {
            Text(
                text = stringResource(head),
                fontSize = 19.sp,
                fontStyle = FontStyle.Normal,
                fontFamily = FontFamily.Serif,
                letterSpacing = 0.5.sp


            )

                Text(
                    text = stringResource(author),
                    fontSize = 19.sp,
                    fontStyle = FontStyle.Normal,
                    fontFamily = FontFamily.Serif,
                    letterSpacing = 0.5.sp



                )
                Text(text = stringResource(annum), fontSize = 19.sp,
                     fontStyle = FontStyle.Normal,
                     fontFamily = FontFamily.Serif,
                     letterSpacing = 0.5.sp

                )
        }
    }
}

@Composable
fun key(
    Back: () -> Unit,
    ahead: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth()
    ) {
        Button(
            onClick = Back,
            colors = ButtonDefaults.buttonColors(Color(0xFF000080)),
            modifier = Modifier
                .padding(4.dp),

            shape = CircleShape,
            elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
            border = BorderStroke(2.dp, Color.Black),
            contentPadding = PaddingValues(16.dp),

        ) {
            Text(
                text = stringResource(id = R.string.previous),
                textAlign = TextAlign.Center,
                modifier = Modifier.width(125.dp),
                fontSize = 17.sp,
                color = Color.White,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                letterSpacing = 0.5.sp,
                textDecoration = TextDecoration.Underline,
                overflow = TextOverflow.Ellipsis,

            )
        }
        Button(
            onClick = ahead,
            colors = ButtonDefaults.buttonColors(Color(0xFF000080)),
            modifier = Modifier
                .padding(4.dp),


            shape = CircleShape,
            elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
            border = BorderStroke(2.dp, Color.Black),
            contentPadding = PaddingValues(16.dp),

        ) {
            Text(
                text = stringResource(id = R.string.next),
                textAlign = TextAlign.Center,
                modifier = Modifier.width(120.dp),
                fontSize = 17.sp,
                color = Color.White,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                letterSpacing = 0.5.sp,
                textDecoration = TextDecoration.Underline,
                overflow = TextOverflow.Ellipsis

            )

        }
    }
}

@Preview()
@Composable
fun P() {
    ArtworkTheme {
        design()
    }
}